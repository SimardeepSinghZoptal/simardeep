export default Images = {
  backgroundImage: require('./images/Background.png'),
  homeIcon: require('./images/home.png'),
  messageIcon: require('./images/message.png'),
  eyeIcon: require('./images/eye.png'),
  hideEyeIcon: require('./images/hide_eye.png'),
}
