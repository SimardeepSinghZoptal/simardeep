const BASE_URL = 'https://empti.org/empti/public/'

export default {
  LOGIN_URL: BASE_URL + 'api/login',
  HOME_URL: BASE_URL + 'api/user/outletDetail',
  IMAGE_URL: BASE_URL + 'images/containers/',
}
