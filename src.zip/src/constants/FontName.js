import {Platform} from 'react-native'
export default {
  MERRIWEATHER_BOLD: 'Merriweather-Bold',
  MERRIWEATHER_BLACK: 'Merriweather-Black',
  MERRIWEATHER_LIGHT: 'Merriweather-Light',
  MERRIWEATHER_REGULAR: 'Merriweather-Regular',
}